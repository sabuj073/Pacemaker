<?php

$command = shell_exec('python Gui.py');
echo $command;

?>